<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_chingying_huang_traveler
 */

get_header();
?>

	<div id="primary" class="content-area row col-md-8 my-2">

		<main id="main" class="site-main w-100 row">

		<?php
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) :
				?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>
				<?php
			endif;

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

           ?>

        <div class="card col-md-6" style="width: 18rem;">
  <img src='<?php echo the_post_thumbnail_url();?>' class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h5>
    <p class="card-text"><?php the_content();?></p>
    <p class="card-text"><?php echo get_the_date(); ?>; Author: <a href="author/<?php the_author_link(); ?>"> <?php the_author();?></a></p>
    
  </div>
</div>

           <?php

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- #main -->
	</div><!-- #primary -->


<div class="col-md-4 my-2">
	
<?php
get_sidebar();
?>
</div>
<?php
get_footer();

