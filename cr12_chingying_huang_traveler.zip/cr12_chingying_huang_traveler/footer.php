<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_chingying_huang_traveler
 */

?>
   </div>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer text-center bg-white">
		<div class="site-info">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'cr12_chingying_huang_traveler' ) ); ?>">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'welcome to', 'cr12_chingying_huang_traveler' ), 'WordPress' );
				?>
			</a>
			<span class="sep"> | </span>
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'copyright: %1$s by %2$s.', 'cr12_chingying_huang_traveler' ), 'cr12_chingying_huang_traveler', '<a href="http://underscores.me/">Underscores.me</a>' );
				?>
		</div><!-- .site-info -->
		 <div class="d-flex justify-content-around p-2 bg-white">
            	<a href="https://www.facebook.com/"><span class='px-2'><i class="fab fa-facebook-f "></i></span></a>
            	<a href="https://www.instagram.com/"><span class='px-2'><i class="fab fa-instagram"></i></span></a>
            	<a href="https://twitter.com/"><span class='px-2'><i class="fab fa-twitter "></i></span></a>
            	<a href="https://www.youtube.com/"><span class='px-2'><i class="fab fa-youtube "></i></span></a>
           
           
           
           
            </div>
	</footer><!-- #colophon -->
</div><!-- #page -->


<?php wp_footer(); ?>


</body>
</html>
